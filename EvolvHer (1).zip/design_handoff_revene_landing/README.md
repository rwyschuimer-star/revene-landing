# Handoff: Revène — Landing Page

## Overview
Revène is a daily growth practice for ambitious women — "the daily practice for ambitious women who are ready to stop performing and start becoming." This package is the **marketing landing page** for the founding-circle launch: a long, editorial, single-page scroll that introduces the brand, explains the name and the practice, and ends in a pilot-registration form.

The page ships with **two complete art directions** that swap via a single wrapper class:
- **Maison** — dark, cinematic, image-forward (the default).
- **Atelier** — cream, architectural, type-forward with editorial scaffolding (section numbers, corner labels).

## About the Design Files
The files in `design/` are a **design reference created in HTML/React** — a high-fidelity prototype showing the intended look, copy, and behavior. They are **not meant to be shipped verbatim** to production. The prototype runs React + Babel **in the browser via CDN `<script>` tags** (in-browser JSX transpilation), which is great for design iteration but wrong for production.

Your task is to **recreate this design in the target codebase's environment** — e.g. a real React/Next.js app with a build step, or Vue/Svelte/plain HTML+CSS — using its established patterns, build tooling, and conventions. If no codebase exists yet, choose an appropriate stack (Next.js or Astro are both good fits for a marketing page) and implement it there. Reuse the design's CSS token system more or less as-is; it is already production-shaped.

## Fidelity
**High-fidelity.** Final colors, typography, spacing, copy, and interactions are all settled. Recreate the UI pixel-perfectly. All exact values are documented below and live in `design/tokens/`. The copy in the components is final and approved — reproduce it verbatim (note the accented "Revène" and curly apostrophes; **no hyphens** anywhere in the copy by deliberate editorial choice).

---

## How the prototype is wired

```
design/site/Revene Landing.html      ← entry point; loads React+Babel via CDN, then the JSX files
design/site/revene-landing.css       ← all page layout + the two art-direction systems
design/site/revene-icons.jsx         ← <Mark> component: the hand-drawn line icon set (inline SVG)
design/site/revene-sections.jsx      ← Nav, Hero, Beat, Name, Heart, Founder sections
design/site/revene-sections2.jsx     ← Layers, Cry, Register (form), Footer sections
design/site/revene-landing-app.jsx   ← composes the page, owns Tweaks state, runs scroll-reveal
design/site/tweaks-panel.jsx         ← design-time control panel (NOT part of the product — see below)
design/styles.css                    ← token entry point; @imports the four token files
design/tokens/*.css                  ← colors, fonts, typography, spacing (the design system)
design/assets/                        ← images actually used by the page
```

**Rendering model:** `Revene Landing.html` mounts `<ReveneLanding>` into `#root`. Components are shared across the separate Babel `<script>` files by assigning them to `window` at the bottom of each file — in a real build you'd use normal ES module imports instead.

**The Tweaks panel (`tweaks-panel.jsx`) is a design tool, not a product feature.** It let us toggle art direction, headline, imagery density, etc. during design. **Do not ship it.** Instead, pick the intended production configuration (see "Recommended production config" below) and build that. The interesting variations it exposes are documented so you can decide what's in scope.

---

## Design Tokens

All tokens live in `design/tokens/`. Port these into the target system (CSS custom properties, Tailwind theme, or design-token JSON).

### Colors (`tokens/colors.css`)
| Token | Hex | Role |
|---|---|---|
| `--bone` | `#F4EEE2` | lightest paper / raised surface |
| `--cream` | `#ECE4D6` | primary light surface |
| `--paper` | `#E6DCCA` | warm alternate surface |
| `--sand` | `#D8C9B0` | muted divider |
| `--espresso` | `#2A2018` | primary dark brown (text on light) |
| `--ink` | `#15120D` | black register — darkest surface |
| `--burgundy` | `#4A2530` | extended dark wine (sparingly) |
| `--plum` | `#331F27` | extended deep plum (sparingly) |
| `--periwinkle` | `#8F9DEB` | **SIGNATURE accent** — cool surprise |
| `--chartreuse` | `#D8D451` | energy / sunlit accent |
| `--rust` | `#C24504` | mark color (default contrast) |
| `--pepper` | `#D8392F` | alternate mark color (bolder) |
| `--silver` | `#B9BBB8` | metallic neutral |

Alpha tints are defined for espresso and cream (e.g. `--espresso-72`, `--cream-88`, `--cream-22`) — see the file. Accent roles: `--accent` = periwinkle (the signature), `--accent-2` = rust (the mark). `::selection` is periwinkle on ink.

### Typography (`tokens/typography.css` + `tokens/fonts.css`)
Fonts are loaded from Google Fonts in the prototype; **for production, self-host woff2** and replace the `@import` in `tokens/fonts.css` with local `@font-face`.

| Family | Token | Usage |
|---|---|---|
| **Bodoni Moda** (high-contrast editorial serif, optical sizes + italic) | `--font-display` | headlines, display, pull quotes |
| **WindSong** (script) | `--font-script` | the "Revène" wordmark and rare short asides only — never sentences/UI/body |
| **Hanken Grotesk** (grotesque sans) | `--font-text` | UI, body copy, wide-tracked small-caps labels |
| **Hurricane** (signature script) | `--font-signature` | the founder's sign-off only |
| **Mr De Haviland** (ceremonial script) | `--font-ceremonial` | reserved; invitations/sign-offs only |

Weights: text 300/400/500/600; display 500 (`--w-display`), 600 (`--w-display-bold`). Line heights: display `1.02`, tight `1.12`, body `1.7`. Eyebrow/label tracking: `0.30em`–`0.34em`, uppercase. Most display sizes in the page use `clamp()` for fluid scaling — see the CSS rather than the static scale tokens.

### Spacing, radii, motion (`tokens/spacing.css`)
- **Spacing:** 8-based scale `--sp-1`(4px) → `--sp-10`(128px), with editorial generosity.
- **Radii:** restrained. `--r-none`/`--r-xs`(2)/`--r-sm`(4)/`--r-md`(8), `--r-pill`(100px) for buttons/chips, `--r-icon`(26px) for app-icon squircles. Editorial figures use `16px`/`20px` directly.
- **Borders:** hairlines over shadows — `--border-hair` (1px `--line`), `--border-faint` (1px `--line-faint`).
- **Shadows:** used sparingly; flat + hairline is the default look.
- **Grain:** one continuous SVG film-grain over surfaces (`--grain-url`), rendered via `.rv-page::after` at ~5% opacity (multiply on light, screen on dark).
- **Motion:** `--ease: cubic-bezier(0.22, 0.61, 0.36, 1)` (no bounce), `--dur: 360ms`. Unhurried and certain.

---

## Screens / Views

This is one continuous page. Sections in DOM order, with the section scaffolding (numbers/corner labels) visible only in **Atelier**.

### 1. Nav (`RvNav`)
- Fixed-flow top bar: script wordmark "Revène" (links `#top`) on the left; right group of links "The name" (`#name`), "The practice" (`#layers`), and a pill button "I am ready" (`#register`).
- Pill button: 1px border `--rule`, `border-radius:100px`, padding `9px 18px`. **Hover:** fills with `--accent` (periwinkle), text → `--ink`.

### 2. Hero (`RvHero`)
- **Maison:** full-bleed background photo (`founder-dusk-crossing.jpg`), min-height 92vh, with a left-to-right ink gradient scrim (`rgba(21,18,13,…)` 0.95→0.32) so copy stays legible over the image. Copy left-aligned, max-width 720px.
- **Atelier:** two-column grid (1.04fr / 0.96fr) — type left, a contained 4:5 photo right (`founder-warmth-doorway.jpg`) with a rust `<Mark name="eye">` badge clipped to the bottom-right corner and a "Revène · Edition 01 — 2026" corner label. Collapses to one column below 860px.
- Content: eyebrow "A daily growth practice"; the script brandmark "Revène" (`clamp(66px,10.5vw,138px)` Maison / `clamp(72px,10vw,130px)` Atelier); the italic declaration "Authentic. Ambitious. Unapologetically Both." in `--accent`; a display headline; a lede paragraph; actions row = primary CTA "Begin" (pill, periwinkle fill) + "Read on ↓" scrollcue.
- **Headline** is one of three (Tweak-selected; pick one for production):
  - `season` (default): "One daily step toward her biggest season yet."
  - `split`: "Lead without splitting yourself in two."
  - `choose`: "You don't have to choose anymore."

### 3. Beat / recognition (`RvBeat`)
- A light-on-dark "cream beat" (`.rv-onlight`) that re-themes local tokens to the bone surface even inside Maison, so the long dark scroll breathes.
- Two-column split: a tall key figure (`g07_0_1.png`) with a small inset image tucked into its lower-left corner (`g01_0_0.png` — a pearl in an oyster) and an asterisk mark top-right; alongside a large italic pull-quote.

### 4. Name (`RvName`)
- Explains the name "Revène" (from *revenir*, to return). A "media-left" split: a wide key figure (`eye-portrait.png`) with a round-mirror inset (`g04_0_1.png`).
- **The two truths** — a 2-col grid of two `.rv-truth` blocks ("return" themed in periwinkle, "rise" themed in rust), each a hairline-topped card with a tag, a small mark, a serif `h3`, and body copy. Collapses to one column below 720px.

### 5. Heart (`RvHeart`)
- The emotional core. A media-left split: a tall key figure with a glass-of-ice inset (`glass-ice.png`) in the corner, beside a large serif "lead line" with italic periwinkle emphasis.
- Default (non-personal) figure: `refs/suede-tie.png` ("a knotted suede tie at the neckline"), flame mark, caption "The fire, never gone." (A dormant `personal` variant swaps in a portrait + eye mark — not currently enabled.)

### 6. Layers — Grow / Explore / Connect (`RvLayers`)
- Section intro + a 2-col card grid (1.15fr / 1fr) describing the three layers of the practice. One **feature** card spans two rows. Cards: subtle tinted fill, hairline border, `border-radius:20px`, generous padding, min-height 230px.
- **Hover:** lift `translateY(-5px)`, border darkens to `--line`, soft shadow `0 26px 54px rgba(42,32,24,0.12)`. Each card has a large faint index numeral top-right, a line mark, an eyebrow, a serif name with an accent word + a 32×2px rust underline, and body copy. Collapses to one column below 820px.

### 7. Cry (`RvCry`)
- Always-dark punctuation band (forced `--ink`/`--cream` regardless of art direction). Faint background image (`g05_0_0.png`) at 40% opacity under a radial ink gradient. Centered: a large line mark, then a huge serif line `clamp(32px,5.4vw,76px)` with an italic periwinkle phrase. Vertical padding `clamp(96px,16vh,200px)`.

### 8. Founder note (`RvFounder`) — optional
- A personal note from Rachelle (founder). Two-column grid: a 4:5 portrait (`founder-portrait.jpg`) with a rust leaf mark in the corner, beside a serif lead (italic periwinkle emphasis), body copy, and a script signature in `--font-signature` (Hurricane) followed by a small-caps role line.
- Toggleable; **on by default**. Keep it for production unless brand decides otherwise.

### 9. Register / pilot (`RvRegister`)
- The conversion section, id `#register`. Two-column grid (0.92fr / 1.08fr), collapses to one column below 900px.
- **Left:** "Revène opens first to a small founding circle." headline + lede; an asterisk note ("This is not a newsletter. It is a declaration…"); and a "What you are saying yes to" list of three hairline-separated items (Four weeks five minutes a day / Free for the founding circle / Feedback and our closest care), each with a line mark.
- **Right:** the signup form — fields **Your name** (text, required), **Where to reach you** (email, required), **What would you like to see in your life right now?** (textarea, optional), **Where you are** (city, optional). Inputs are borderless with a hairline bottom border that turns periwinkle on focus. Submit button "I am ready" (periwinkle pill) is disabled until name is present and email matches `/\S+@\S+\.\S+/`.
- **On submit:** the form swaps to a confirmation state — leaf mark, "You are among the first through the door.", a personalized paragraph using the first name + email, and the sign-off "The rise is hers. The rise is ours." **See "Form behavior" below — this needs a real backend in production.**

### 10. Footer (`RvFooter`)
- Hairline-topped. Script wordmark + italic declaration on the left; contact meta on the right (`revene.co`, `hello@revene.co`, `@joinrevene`). A slogan row beneath, separated by a faint hairline, with the brand promise and "© 2026 Revène".

---

## Interactions & Behavior

- **Scroll reveal:** elements with `.rv-reveal` start at `opacity:0; translateY(18px)` and animate in (`0.9s` ease) when they cross ~92% of the viewport, via `data-in` / `.is-in`. Optional stagger delays `.d1`/`.d2`/`.d3`. Gated behind `@media (prefers-reduced-motion: no-preference)` — reduced-motion users see content immediately. In a real build, use a simple `IntersectionObserver`; the prototype adds a capture-phase scroll listener + polling fallback only because sandboxed preview iframes are unreliable — **you do not need that workaround.**
- **Hover states:** nav pill fills periwinkle; CTA lifts 1px and dims slightly; layer cards lift + shadow; chips/links shift to full-contrast foreground.
- **Form validation:** client-side only (name non-empty + email regex). Submit disabled until valid.
- **Marks:** the hand-drawn `<Mark>` set is inline SVG using `currentColor` and round caps (eye, leaf, flame, butterfly, asterisk). The asterisk is the brand seal; it recurs as the eye's pupil. A `.marks-off` mode hides them all (design toggle).
- **Responsive:** every major grid has a documented single-column breakpoint (860/880/820/900/720px). Spacing uses `clamp()` throughout; verify on mobile.

## Form behavior — IMPORTANT for production
The prototype's form has **no backend** — on submit it only flips to the local thank-you state; nothing is stored or sent. For production you must wire it to a real destination: an email/CRM list (Mailchimp, ConvertKit, Customer.io), a form service (Formspree, Tally), or your own API endpoint. Add server-side validation, spam protection (honeypot/Turnstile), a privacy/consent line, and a genuine success/error state. The "founding circle" framing implies you'll also want to store name, email, optional free-text wish, and optional city.

## State Management
Minimal. Production state needed:
- **Register form:** `name`, `email`, `city`, `wish`, plus `submitted`/`error`/`loading` for the async submit. (Prototype uses local `useState` + a synchronous `done` flag.)
- **Scroll reveal:** no React state — driven by an observer toggling a class/attribute.
- The art-direction / headline / density / marks / founder-note values are **design-time Tweaks**, not runtime product state. Bake the chosen configuration in (see below) rather than shipping toggles.

## Recommended production config
Unless brand directs otherwise, ship: **Maison** art direction, **`season`** headline ("One daily step toward her biggest season yet."), **Rich** imagery, **marks on**, **founder note on**. These are the prototype defaults (`TWEAK_DEFAULTS` in `revene-landing-app.jsx`).

## Assets
In `design/assets/` — only the images the page actually renders are included. Replace any that are placeholders with final licensed/brand photography before launch.

| File | Used in |
|---|---|
| `founder/founder-dusk-crossing.jpg` | Maison hero background |
| `founder/founder-warmth-doorway.jpg` | Atelier hero photo |
| `founder/founder-portrait.jpg` | Founder note portrait |
| `photos/g07_0_1.png` | Beat — key figure |
| `photos/g01_0_0.png` | Beat — corner inset (pearl/oyster) |
| `refs/eye-portrait.png` | Name — key figure |
| `photos/g04_0_1.png` | Name — mirror inset |
| `refs/suede-tie.png` | Heart — key figure (default) |
| `photos/glass-ice.png` | Heart — corner inset |
| `photos/g05_0_0.png` | Cry — faint background |

Icons are **not** asset files — they are inline SVG in `revene-icons.jsx` (`<Mark>` component). Port them as React/Vue components or an SVG sprite.

## Files to reference
- Layout + both art-direction systems: `design/site/revene-landing.css`
- Section markup & final copy: `design/site/revene-sections.jsx`, `design/site/revene-sections2.jsx`
- Page composition, defaults, reveal logic: `design/site/revene-landing-app.jsx`
- Icon set: `design/site/revene-icons.jsx`
- Design tokens: `design/styles.css` → `design/tokens/{colors,fonts,typography,spacing}.css`

To run the prototype as-is for reference: serve the `design/` folder over a local static server (e.g. `npx serve design`) and open `site/Revene Landing.html` — it needs HTTP (not `file://`) because of the module/asset loading. Append `?dir=atelier` to preview the Atelier direction.
