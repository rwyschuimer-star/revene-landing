// revene-sections.jsx — landing-page sections. Copy is verbatim from the
// approved Copy Deck. No hyphens; accents preserved (Revène, ís). Shared markup;
// the .dir-maison / .dir-atelier wrapper class drives the two visual systems.

const IMG = '../assets/photos/';
const REF = '../assets/refs/';
const MAT = '../assets/MATERNITY/';
const FND = '../assets/founder/';

// ── Nav ──────────────────────────────────────────────────────────────────────
function RvNav() {
  return (
    <nav className="rv-nav">
      <a className="brand" href="#top" style={{ textDecoration: 'none' }}>Revène</a>
      <div className="right">
        <a href="#name">The name</a>
        <a href="#layers">The practice</a>
        <a className="ready" href="#register">I am ready</a>
      </div>
    </nav>
  );
}

// ── Hero ─────────────────────────────────────────────────────────────────────
function RvHero({ headline, dir }) {
  const hero = dir === 'atelier'
    ? { src: FND + 'founder-warmth-doorway.jpg', alt: 'A woman walking past a warm-lit doorway at golden hour' }
    : { src: FND + 'founder-dusk-crossing.jpg', alt: 'A woman crossing the street at dusk, turning to look back' };
  return (
    <header className="rv-hero" id="top">
      <div className="rv-hero-media">
        <span className="corner rv-scaffold">Revène · Edition 01 — 2026</span>
        <img src={hero.src} alt={hero.alt} />
        <Mark name="eye" className="h-mark" />
      </div>
      <div className="rv-hero-copy">
        <div className="rv-hero-inner">
          <span className="rv-eyebrow rv-reveal is-in">A daily growth practice</span>
          <div className="brandmark rv-reveal is-in d1" style={{ marginTop: 14 }}>Revène</div>
          <p className="declaration rv-reveal is-in d2">Authentic. Ambitious. Unapologetically Both.</p>
          <p className="headline rv-display rv-reveal is-in d3">{headline}</p>
          <p className="rv-lede rv-hero-sub rv-reveal is-in d3">
            Revène is the daily practice for ambitious women who are ready to stop performing and start becoming.
          </p>
          <div className="rv-hero-actions rv-reveal is-in d3">
            <a className="rv-cta" href="#register">Begin<span className="dot" /></a>
            <span className="scrollcue">Read on ↓</span>
          </div>
        </div>
      </div>
    </header>
  );
}

// ── Beat (recognition) ─────────────────────────────────────────────────────────
function RvBeat() {
  return (
    <section className="rv-section rv-beat rv-onlight">
      <div className="rv-wrap">
        <div className="rv-split">
          <div>
            <div className="rv-scaffold" style={{ marginBottom: 28 }}>
              <span className="rv-sectnum">01 — Recognition</span>
            </div>
            <p className="rv-prose pull rv-reveal">
              You are doing well on paper. You have worked hard for it. Very hard, in more directions than anyone fully sees.
            </p>
            <div className="rv-prose rv-reveal d1">
              <p>
                And still. The feeling persists. That the effort is real but the fulfilment is not quite there. That the
                recognition never fully reflects what you actually bring. That you are capable of a larger impact than the
                one you are currently having.
              </p>
              <p>You cannot always explain it. <span className="know">You just know.</span></p>
              <p>
                Revène is where that knowing finally has somewhere to go. Not another programme asking you to do more. A
                daily practice of going deeper and further, at once.
              </p>
            </div>
          </div>
          <div className="rv-figure tall key rv-reveal d1" data-optional>
            <img src={IMG + 'g07_0_1.png'} alt="A woman in black, silver cuffs at her wrists" />
            <div className="inset"><img src={IMG + 'g01_0_0.png'} alt="A pearl resting in an open oyster" /></div>
            <Mark name="asterisk" className="fig-mark tr" />
          </div>
        </div>
      </div>
    </section>
  );
}

// ── Name (two truths) ──────────────────────────────────────────────────────────
function RvName() {
  return (
    <section className="rv-section rv-name" id="name">
      <div className="rv-wrap rv-narrow">
        <div className="rv-scaffold" style={{ marginBottom: 28 }}>
          <span className="rv-sectnum">02 — On the name</span>
        </div>
        <span className="rv-eyebrow rv-reveal">One name. Two truths.</span>
        <p className="revenir rv-display italic rv-reveal d1" style={{ marginTop: 18 }}>
          From <b>revenir</b> — to return. Come back to yourself, and bring your fire with you.
        </p>
        <div className="truths">
          <div className="rv-truth return rv-reveal d1">
            <span className="tag"><Mark name="leaf" className="tmark" />Rooted · the return</span>
            <h3>She returns to herself.</h3>
            <p>
              To her own clarity, her own strengths, the version of herself that exists beneath the performance. The
              parts she set aside in order to keep up. She did not lose them. There is a profound difference.
            </p>
          </div>
          <div className="rv-truth rise rv-reveal d2">
            <span className="tag"><Mark name="flame" className="tmark" />Rising · the fire</span>
            <h3>She brings her fire forward.</h3>
            <p>
              The impact that was always possible. The rooms that were always meant to be hers. Ambition and authenticity
              are not opposing forces. Both are always present. Neither asks her to choose.
            </p>
          </div>
        </div>
        <div className="rv-split media-left" style={{ marginTop: 'clamp(40px, 5vw, 72px)' }}>
          <div className="rv-figure wide key rv-reveal" data-optional>
            <img src={REF + 'eye-portrait.png'} alt="Two faces held in a single frame, a hand-drawn eye between them" />
            <div className="inset"><img src={IMG + 'g04_0_1.png'} alt="A round mirror reflecting trees and sky" /></div>
          </div>
          <p className="rv-prose pull rv-reveal d1">
            The return that makes the rise possible. The name is the philosophy.
          </p>
        </div>
      </div>
    </section>
  );
}

// ── Heart narrative ──────────────────────────────────────────────────────────
function RvHeart({ personal }) {
  const fig = personal
    ? { src: MAT + 'Rachelle-12.jpg', alt: 'A woman looks back over her shoulder, a crown of wildflowers in her hair', mark: 'eye', cap: 'She already knows' }
    : { src: REF + 'suede-tie.png', alt: 'A crisp white collar and a knotted suede tie pinned at the neckline', mark: 'flame', cap: 'The fire, never gone' };
  return (
    <section className="rv-section rv-heart">
      <div className="rv-wrap">
        <div className="rv-split media-left">
          <div className="rv-figure tall key rv-reveal" data-optional>
            <img src={fig.src} alt={fig.alt} />
            <div className="inset"><img src={IMG + 'glass-ice.png'} alt="A faceted crystal tumbler holding a single clear block of ice" /></div>
            <Mark name={fig.mark} className="fig-mark tr" />
          </div>
          <div>
            <p className="lead-line rv-reveal">
              She deserves more. She has always known it. And she is <em>tired of being the only one in the room who does.</em>
            </p>
            <div className="rv-prose rv-reveal d1" style={{ marginTop: 28 }}>
              <p>
                Not more things. More meaning in the work she does. More impact than the current version of her life is
                making room for. More of herself in the equation.
              </p>
              <p>
                Those parts are not liabilities. They are the most powerful thing about her. The truth she returns to and
                the fire she was always meant to bring forward. She just never had the right conditions to fully develop
                them.
              </p>
              <p className="pull" style={{ marginTop: 24 }}>Revène is those conditions.</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

// ── Founder's note (the human layer — routed through Rachelle so the personal
// imagery reads as the founder, not a category claim) ─────────────────────────
function RvFounder() {
  return (
    <section className="rv-section rv-founder rv-onlight" id="founder">
      <div className="rv-wrap">
        <div className="rv-scaffold" style={{ marginBottom: 36 }}>
          <span className="rv-sectnum">A note from the founder</span>
        </div>
        <div className="grid">
          <div className="portrait rv-reveal" data-optional>
            <img src={FND + 'founder-portrait.jpg'} alt="Rachelle, founder of Revène" />
            <Mark name="leaf" className="fmark" />
          </div>
          <div className="note">
            <p className="lead rv-reveal">I am building Revène from the <em>inside.</em></p>
            <div className="rv-prose body rv-reveal d1">
              <p>
                I know the split, because I have lived it. The work that looks like success from the outside, and the
                quiet certainty that there is more of me than the day is making room for.
              </p>
              <p>
                Revène is the practice I needed. A daily return to what is true, and the courage to bring it forward. I
                am building it slowly, in the company of women who feel the same.
              </p>
            </div>
            <p className="sign rv-reveal d1">Rachelle</p>
            <p className="role rv-reveal d1">Founder of Revène</p>
          </div>
        </div>
      </div>
    </section>
  );
}

Object.assign(window, { RvNav, RvHero, RvBeat, RvName, RvHeart, RvFounder });
