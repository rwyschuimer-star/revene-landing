// revene-icons.jsx — the mark set, drawn as elegant simple lines.
// One refined single-weight hand: clean strokes, round caps, no texture filter —
// legible and graceful at every size. Marks: eye, leaf/sprig (return),
// flame (rise), butterfly (becoming), asterisk seal. The asterisk recurs as the
// eye's pupil — the seal DNA.
//
// Paths are inlined per <Mark> (not <use>) so currentColor resolves correctly.

// No shared filter needed for line work; kept as a no-op so callers/markup don't change.
function RvSprite() { return null; }

const RV_PATHS = {
  eye: (
    <React.Fragment>
      <path d="M7 52 Q50 19 93 52" />
      <path d="M7 52 Q50 85 93 52" />
      <circle cx="50" cy="52" r="14.5" />
      <path d="M50 41 L50 63 M40.5 46 L59.5 58 M59.5 46 L40.5 58" />
    </React.Fragment>
  ),
  leaf: (
    <React.Fragment>
      <path d="M50 7 C25 30 25 67 50 93 C75 67 75 30 50 7 Z" />
      <path d="M50 15 L50 87" />
      <path d="M50 39 Q39 43 32 39 M50 56 Q61 60 68 56" />
    </React.Fragment>
  ),
  flame: (
    <React.Fragment>
      <path d="M50 93 C23 76 30 43 50 7 C70 43 77 76 50 93 Z" />
      <path d="M50 81 C40 72 43 57 52 46 C59 58 58 72 50 81 Z" />
    </React.Fragment>
  ),
  butterfly: (
    <React.Fragment>
      <path d="M50 35 L50 77" />
      <path d="M50 33 Q44 21 38 16 M50 33 Q56 21 62 16" />
      <path d="M50 41 C29 20 10 37 25 52 C36 61 47 52 50 45" />
      <path d="M50 41 C71 20 90 37 75 52 C64 61 53 52 50 45" />
      <path d="M50 50 C35 59 28 75 43 79 C50 81 51 70 50 60" />
      <path d="M50 50 C65 59 72 75 57 79 C50 81 49 70 50 60" />
    </React.Fragment>
  ),
  asterisk: (
    <React.Fragment>
      <path d="M50 15 L50 85 M21 31 L79 69 M79 31 L21 69" />
    </React.Fragment>
  ),
};

// per-mark stroke weight (viewBox 0 0 100) — elegant + thin; butterfly a touch finer
const RV_STROKE = { butterfly: 3.1 };

function Mark({ name, className = '', style, title }) {
  const sw = RV_STROKE[name] || 3.6;
  return (
    <span className={`rv-mark ${className}`} style={style} role="img" aria-label={title || name}>
      <svg viewBox="0 0 100 100">
        <g fill="none" stroke="currentColor" strokeWidth={sw} strokeLinecap="round" strokeLinejoin="round">
          {RV_PATHS[name] || RV_PATHS.eye}
        </g>
      </svg>
    </span>
  );
}

Object.assign(window, { RvSprite, Mark });
