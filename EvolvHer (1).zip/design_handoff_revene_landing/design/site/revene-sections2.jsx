// revene-sections2.jsx — Layers (Grow/Explore/Connect), the rallying-cry
// punctuation, the pilot registration (with motivation prompt + confirmation),
// and the footer. Copy verbatim from the approved Copy Deck.

const IMG2 = '../assets/photos/';

// ── The three layers ─────────────────────────────────────────────────────────
function RvLayers() {
  const layers = [
    { mark: 'leaf', eyebrow: 'The heartbeat', name: 'Grow',
      body: 'Her daily practice. One invitation every day that builds her clarity, her confidence and her connection to her own power. It takes five minutes. Never more than she has.' },
    { mark: 'eye', eyebrow: 'For when she wants to go further', name: 'Explore',
      body: 'Depth and frameworks on the topics women rarely find addressed with the honesty and sophistication they deserve. Oriented by dimension, never by category.' },
    { mark: 'butterfly', eyebrow: 'Her village', name: 'Connect',
      body: 'Ambitious, inspiring women on the same journey. Her Circles. Her Give and Receive board. Women who show up for each other the way they show up for themselves.' },
  ];
  return (
    <section className="rv-section rv-layers rv-onlight" id="layers">
      <div className="rv-wrap">
        <div className="rv-scaffold" style={{ marginBottom: 28 }}>
          <span className="rv-sectnum">03 — What Revène actually is</span>
        </div>
        <p className="rv-display rv-reveal" style={{ fontSize: 'clamp(26px,3.4vw,46px)', maxWidth: '18em' }}>
          Three layers, each one designed to support a different dimension of her growth.
        </p>
        <div className="grid">
          {layers.map((l, i) => (
            <div className={`rv-layer ${i === 0 ? 'feature' : ''} rv-reveal d${i + 1}`} key={l.name}>
              <span className="lindex">{String(i + 1).padStart(2, '0')}</span>
              <Mark name={l.mark} className="lmark" />
              <div className="lbody">
                <span className="leyebrow">{l.eyebrow}</span>
                <span className="lname rv-display"><span className="accent">{l.name}.</span></span>
                <p>{l.body}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// ── Rallying cry ─────────────────────────────────────────────────────────────
function RvCry() {
  return (
    <section className="rv-section rv-cry">
      <div className="bg" data-optional><img src={IMG2 + 'g05_0_0.png'} alt="" /></div>
      <div className="rv-wrap">
        <div className="inner rv-reveal">
          <Mark name="butterfly" className="cmark" />
          <p className="line">
            The rise is hers.<br /><span className="peri">The rise is ours.</span>
          </p>
        </div>
      </div>
    </section>
  );
}

// ── Pilot registration ───────────────────────────────────────────────────────
const MOTIVES = [
  'I feel like two different people at work and at home',
  'The fulfilment has not caught up with the effort',
  'I am doing this alone and no one quite gets it',
  'I am always performing, never just being',
  'I am ready and I do not fully know why yet',
];

function RvRegister() {
  const [name, setName] = React.useState('');
  const [email, setEmail] = React.useState('');
  const [city, setCity] = React.useState('');
  const [wish, setWish] = React.useState('');
  const [done, setDone] = React.useState(false);
  const valid = name.trim() && /\S+@\S+\.\S+/.test(email);

  const submit = (e) => {
    e.preventDefault();
    if (!valid) return;
    setDone(true);
  };

  return (
    <section className="rv-section rv-register" id="register">
      <div className="rv-wrap">
        <div className="rv-scaffold" style={{ marginBottom: 36 }}>
          <span className="rv-sectnum">04 — The invitation</span>
        </div>
        <div className="rv-reg-grid">
          <div className="rv-reg-intro rv-reveal">
            <h2 className="rv-display">Revène opens first to a small founding circle.</h2>
            <p className="rv-lede lede">
              Build slowly, with deeply engaged women. The first cohort is intentionally small. Leave your name and be
              among the first through the door. We will write to you when it begins.
            </p>
            <div className="rv-reg-note">
              <Mark name="asterisk" className="nmark" />
              <span>This is not a newsletter. It is a declaration. There is no pressure here, and no streaks. One moment, when you are ready.</span>
            </div>
            <div className="rv-reg-expect">
              <p className="exlabel">What you are saying yes to</p>
              <div className="ex">
                <Mark name="leaf" className="exmark" />
                <div className="extx">
                  <div className="exh">Four weeks, five minutes a day</div>
                  <div className="exp">A focused four-week pilot. One short daily practice — never more than you have.</div>
                </div>
              </div>
              <div className="ex">
                <Mark name="asterisk" className="exmark" />
                <div className="extx">
                  <div className="exh">Free for the founding circle</div>
                  <div className="exp">No charge for the pilot. Founding members keep the founding-member rate when Revène opens fully.</div>
                </div>
              </div>
              <div className="ex">
                <Mark name="eye" className="exmark" />
                <div className="extx">
                  <div className="exh">Feedback, and our closest care</div>
                  <div className="exp">We ask for your honest reflections as you go. In return, the first circle has our full attention — held with extra care.</div>
                </div>
              </div>
            </div>
          </div>

          <div className="rv-reveal d1">
            {!done ? (
              <form className="rv-form" onSubmit={submit}>
                <div className="rv-field">
                  <label htmlFor="rv-name">Your name</label>
                  <input id="rv-name" type="text" value={name} placeholder="First name"
                         onChange={(e) => setName(e.target.value)} autoComplete="given-name" />
                </div>
                <div className="rv-field">
                  <label htmlFor="rv-email">Where to reach you</label>
                  <input id="rv-email" type="email" value={email} placeholder="you@example.com"
                         onChange={(e) => setEmail(e.target.value)} autoComplete="email" />
                </div>
                <div className="rv-field">
                  <label htmlFor="rv-wish">What would you like to see in your life right now?</label>
                  <textarea id="rv-wish" value={wish} rows={3}
                            placeholder="In your own words — there is no wrong answer."
                            onChange={(e) => setWish(e.target.value)}></textarea>
                  <p className="hint">Optional. Share as much or as little as you like.</p>
                </div>
                <div className="rv-field">
                  <label htmlFor="rv-city">Where you are</label>
                  <input id="rv-city" type="text" value={city} placeholder="City — optional, for in-person Circles"
                         onChange={(e) => setCity(e.target.value)} autoComplete="address-level2" />
                </div>
                <div className="submit-row">
                  <button type="submit" className="rv-cta" disabled={!valid}
                          style={{ opacity: valid ? 1 : 0.5 }}>I am ready<span className="dot" /></button>
                  <span className="fineprint">No spam. One note when the door opens, and nothing you did not ask for.</span>
                </div>
              </form>
            ) : (
              <div className="rv-confirm">
                <Mark name="leaf" className="cmark" />
                <h3>You are among the first through the door.</h3>
                <p>
                  {name.trim().split(' ')[0]}, your place in the founding circle is held. We will write to
                  {email ? ' ' + email : ' you'} when Revène begins. Until then, nothing is asked of you.
                </p>
                <p className="sig">The rise is hers. The rise is ours.</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}

// ── Footer ───────────────────────────────────────────────────────────────────
function RvFooter() {
  return (
    <footer className="rv-footer">
      <div className="rv-wrap">
        <div className="top">
          <div>
            <div className="brand">Revène</div>
            <p className="decl">Authentic. Ambitious. Unapologetically Both.</p>
          </div>
          <div className="meta">
            <div><a href="https://revene.co">revene.co</a></div>
            <div><a href="mailto:hello@revene.co">hello@revene.co</a></div>
            <div><a href="#top">@joinrevene</a></div>
          </div>
        </div>
        <div className="slogan">
          <span className="s">The daily practice for ambitious women who have decided to stop performing and start becoming.</span>
          <span className="c">© 2026 Revène</span>
        </div>
      </div>
    </footer>
  );
}

Object.assign(window, { RvLayers, RvCry, RvRegister, RvFooter });
