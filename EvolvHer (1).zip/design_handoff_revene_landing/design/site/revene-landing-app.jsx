// revene-landing-app.jsx — composes the page, owns the Tweaks panel, drives
// the two art directions, and runs the scroll-reveal observer.

const HEADLINES = {
  season: 'One daily step toward her biggest season yet.',
  split: 'Lead without splitting yourself in two.',
  choose: 'You don\u2019t have to choose anymore.',
};

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "direction": "maison",
  "headline": "season",
  "density": "rich",
  "marks": true,
  "founder": true
}/*EDITMODE-END*/;

function ReveneLanding() {
  // URL ?dir= wins on first load so the Directions canvas can pin each frame.
  const urlDir = (() => {
    try { return new URLSearchParams(window.location.search).get('dir'); }
    catch (e) { return null; }
  })();
  const initial = { ...TWEAK_DEFAULTS };
  if (urlDir === 'maison' || urlDir === 'atelier') initial.direction = urlDir;

  const [t, setTweak] = useTweaks(initial);

  // Scroll reveal. Sandboxed preview iframes are inconsistent about where the
  // scroll event lands (window vs an inner element) and IntersectionObserver can
  // be inert, so we (a) listen in capture phase to catch scroll from any
  // scroller and (b) keep a lightweight poll that self-terminates once
  // everything has been shown. Belt and braces — but it always reveals.
  React.useEffect(() => {
    let raf = 0;
    const reveal = () => {
      raf = 0;
      const vh = window.innerHeight || document.documentElement.clientHeight;
      // data-in (not is-in class) so React reconciliation can't strip a revealed
      // element when its component re-renders (e.g. the form swapping to confirm).
      const sel = '.rv-reveal:not(.is-in):not([data-in])';
      document.querySelectorAll(sel).forEach((el) => {
        if (el.getBoundingClientRect().top < vh * 0.92) el.setAttribute('data-in', '');
      });
      return document.querySelectorAll(sel).length;
    };
    const onScroll = () => { if (!raf) raf = requestAnimationFrame(reveal); };
    reveal();
    window.addEventListener('scroll', onScroll, true);
    window.addEventListener('resize', onScroll);
    const iv = setInterval(() => { if (reveal() === 0) clearInterval(iv); }, 220);
    return () => {
      window.removeEventListener('scroll', onScroll, true);
      window.removeEventListener('resize', onScroll);
      clearInterval(iv);
      if (raf) cancelAnimationFrame(raf);
    };
  }, [t.direction, t.density, t.marks, t.headline, t.founder]);

  const pageClass = [
    'rv-page',
    t.direction === 'atelier' ? 'dir-atelier' : 'dir-maison',
    t.density === 'spare' ? 'density-spare' : '',
    t.marks ? '' : 'marks-off',
  ].join(' ').trim();

  return (
    <div className={pageClass}>
      <RvSprite />
      <RvNav />
      <RvHero headline={HEADLINES[t.headline] || HEADLINES.season} dir={t.direction} />
      <RvBeat />
      <RvName />
      <RvHeart />
      <RvLayers />
      <RvCry />
      {t.founder ? <RvFounder /> : null}
      <RvRegister />
      <RvFooter />

      <TweaksPanel title="Tweaks">
        <TweakSection label="Direction" />
        <TweakRadio label="Art direction" value={t.direction}
                    options={[{ value: 'maison', label: 'Maison' }, { value: 'atelier', label: 'Atelier' }]}
                    onChange={(v) => setTweak('direction', v)} />
        <TweakSection label="Hero" />
        <TweakSelect label="Headline" value={t.headline}
                     options={[
                       { value: 'season', label: 'Her biggest season yet' },
                       { value: 'split', label: 'Without splitting in two' },
                       { value: 'choose', label: 'You don\u2019t have to choose' },
                     ]}
                     onChange={(v) => setTweak('headline', v)} />
        <TweakSection label="Composition" />
        <TweakRadio label="Imagery" value={t.density}
                    options={[{ value: 'rich', label: 'Rich' }, { value: 'spare', label: 'Spare' }]}
                    onChange={(v) => setTweak('density', v)} />
        <TweakToggle label="Hand-drawn marks" value={t.marks}
                     onChange={(v) => setTweak('marks', v)} />
        <TweakToggle label="Founder note" value={t.founder}
                     onChange={(v) => setTweak('founder', v)} />
      </TweaksPanel>
    </div>
  );
}

Object.assign(window, { ReveneLanding });
